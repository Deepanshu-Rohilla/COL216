#include <iostream>
#include <fstream>
#include <map>
#include <math.h>
#include <unordered_map>
#include <map>
#include <vector>
#include <set>
#include <queue>

using namespace std;

int maxQueueSizePermitted = 32;
int simulation_time;
int x = pow(2, 20);
int cnt1 = -1;
int row = -1;
int col = -1;

int ROW_ACCESS_DELAY;
int COL_ACCESS_DELAY;
int number_of_row_buffer_update = 0;

int idx_num;
int delay_num;
int num_of_CPU_cores;
vector<map<pair<int, int>, int>> reg_val; // Aur isko kaise karna hai?
vector<pair<int, int>> dramMemoryRange;
set<pair<int, int>> busy_cycle_time;
set<pair<int, int>> busy_cycle_time1;
vector<vector<int>> Instruction_command_mem; // Initially an array
vector<vector<int>> registers2D;
vector<vector<int>> freqOfCommand2D;
unordered_map<string, int> instructionNumber;
vector<int> numberOfClockCycles;
vector<int> excess;
vector<bool> choice;
vector<bool> instruction_halted;
vector<int> line;
string Register_map[32];
deque<vector<int>> queueArray[1024]; // Queue
vector<pair<int, int>> v_line_no;
vector<int> counter;
vector<int> numberOfCyclesForEachCore;
int DRAM[1024][1024];
int Row_Buffer[1024];

void update_cycle(int st, int ed, int coreNumber)
{
    int x = st, y = ed;
    //cout<<"hi"<<"\n";
    int flag = 0;
    //cout<<st<<"::"<<ed<<"\n";
    if (busy_cycle_time.size() != 0)
    {
        auto it = busy_cycle_time.begin();
        while (it != busy_cycle_time.end())
        {
            if ((x <= (*it).second && x >= (*it).first) || (y <= (*it).second && y >= (*it).first))
            {

                x = (*it).second + 1;
                y = (*it).second + (ed - st + 1);
                flag = -1;
                //cout<<"hello"<<x<<" "<<y<<"\n";
            }
            else if (x <= (*it).first && y >= (*it).second)
            {
                x = (*it).second + 1;
                y = (*it).second + (ed - st + 1);
                flag = -1;
            }
            it++;
        }
    }
    else
    {
        busy_cycle_time.insert({st, ed});
    }
    busy_cycle_time.insert({x, y});
    // cout<<x<<" "<<y<<"\n";
    if (flag == -1)
    {
        if (!choice[coreNumber])
        {
            int excess_cycle = y - (x + excess[coreNumber]);
            if (excess_cycle > 0)
                excess[coreNumber] += excess_cycle;
        }
    }
    // cout<<counter[coreNumber]<<"-->"<<"\n";
    //int excess_cycle=
    // cout<<excess[coreNumber]<<"->"<<"\n";
    numberOfClockCycles[coreNumber] = x;
}

void update_cycle1(int st, int ed, int coreNumber)
{
    int x = st, y = ed;
    if (busy_cycle_time1.size() != 0)
    {
        auto it = busy_cycle_time1.begin();
        while (it != busy_cycle_time1.end())
        {
            if ((x <= (*it).second && x >= (*it).first) || (y <= (*it).second && y >= (*it).first))
            {

                x = (*it).second + 1;
                y = (*it).second + 2;
                //cout<<"hello"<<x<<" "<<y<<"\n";
            }
            //     else if (x<=(*it).first && y>=(*it).second){
            //         x=(*it).second;
            //         y=(*it).second+(ed-st+1);
            //    }
            it++;
        }
    }
    else
    {
        busy_cycle_time1.insert({st, ed});
    }
    busy_cycle_time1.insert({x, y});
    // cout<<x<<" "<<y<<"\n";
    // cout<<counter[coreNumber]<<"-->"<<"\n";
    //int excess_cycle=
    // cout<<excess[coreNumber]<<"->"<<"\n";
    numberOfClockCycles[coreNumber] = x;
}

bool check1(int rowno, int coreNumber)
{

    if (dramMemoryRange.at(coreNumber).first <= rowno && dramMemoryRange.at(coreNumber).second >= rowno)
    {
        return true;
    }
    return false;
}
void remove_instruction(int coreNumber)
{

    for (int j = dramMemoryRange.at(coreNumber).first; j <= dramMemoryRange.at(coreNumber).second; j++)
    {

        if (!queueArray[j].empty())
        {
            queueArray[j].clear();
        }
    }
}
bool general_check()
{
    for (int i = 0; i < 1024; i++)
    {
        if (!queueArray[i].empty())
        {
            return true;
        }
    }
    for (int i = 0; i < num_of_CPU_cores; i++)
    {
        if (!instruction_halted[i])
        {
            return true;
        }
    }
    return false;
}
bool check_counter(int coreNumber)
{
    int shuru = dramMemoryRange.at(coreNumber).first;
    int khatam = dramMemoryRange.at(coreNumber).second;
    for (int i = shuru; i <= khatam; i++)
    {
        if (!queueArray[i].empty())
        {
            // cout<<i<<" ";
            return true;
        }
    }
    return false;
}

void load_data(int Row_Buffer[], int DRAM[][1024], int row)
{ //Copy  DRAM to from Row_buffer
    for (int i = 0; i < 1024; i++)
    {
        Row_Buffer[i] = DRAM[row][i];
    }
}

void load_data_back(int Row_Buffer[], int DRAM[][1024], int row)
{ //for Writing back from Row_buffer to DRAM
    for (int i = 0; i < 1024; i++)
    {
        DRAM[row][i] = Row_Buffer[i];
    }
}

string decToHexa(int n)
{
    char hexaDeciNum[100];
    int i = 0;
    if (n == 0)
    {
        return "0";
    }
    else
    {
        while (n != 0)
        {
            int temp = 0;
            temp = n % 16;
            if (temp < 10)
            {
                hexaDeciNum[i] = temp + 48;
                i++;
            }
            else
            {
                hexaDeciNum[i] = temp + 87;
                i++;
            }
            n = n / 16;
        }
    }
    string Hex_Val = "";
    for (int j = i - 1; j >= 0; j--)
        Hex_Val += hexaDeciNum[j];
    return Hex_Val;
}
void printRegisters(vector<int> numberOfClockCycles, int coreNumber)
{
    cout << "Cycle number: " << numberOfClockCycles[coreNumber] << "\n";
    for (int i = 0; i < 32; i++)
    {
        // cout<<" Value stored in $r"<<i<<" is "<<decToHexa(registers[i])<<"\n";
        //cout<<decToHexa(registers[i])<<" ";
        //  cout<<(registers[i])<<" ";
    }
    cout << "\n";
}
void printChange_in_Each_Cycle(int coreNumber, int ROW_ACCESS_DELAY, int COL_ACCESS_DELAY, int type, int instruction_Num, int numberofClockCycles, int &addr, string inst_name, string Register_mod, string Memory, string DARM_Activity)
{
    //cout<<"hi"<<"\n";
    if (instruction_Num != 8 && instruction_Num != 9 && !instruction_halted[coreNumber])
    {
        if (numberofClockCycles > simulation_time)
        {

            cout << "Core No :->" + to_string(coreNumber) + " \n" + "Cycle number " + to_string(simulation_time) + ":\n" + "Instruction Address: " + to_string(addr) + ", Executed Instruction , Modified Register , Modified Memory Location  && Activity on DRAM :: Pending State \n";
            instruction_halted[coreNumber] = true;
        }
        else
        {
            cout << "Core No :->" + to_string(coreNumber) + "\n" + "Cycle number " + to_string(numberofClockCycles) + ": \n" + "Instruction Address: " + to_string(addr) + ", Executed Instruction : " + inst_name + " \n" + "Modified Register :" + Register_mod + " \n" + "Modified Memory Location : " + Memory + "\n" + "Activity on DRAM : " + DARM_Activity + " . \n";
        }
    }

    if ((instruction_Num == 9 || instruction_Num == 8) && !instruction_halted[coreNumber])
    {
        if (type == 0)
        {
            if (numberofClockCycles > simulation_time)
            {
                cout << "Core No :->" + to_string(coreNumber) + "\n" + "Cycle number " + to_string(simulation_time) + ": \n" + "Instruction Address: " + to_string(addr) + ", Executed Instruction , Modified Register , Modified Memory Location && Activity on DRAM :: Pending State \n";
                instruction_halted[coreNumber] = true;
            }
            else
            {

                cout << "Core No :->" + to_string(coreNumber) + "\n" + "Cycle number " + to_string(numberofClockCycles) + ": \n" + "Instruction Address: " + to_string(addr) + ", Executed Instruction : " + inst_name + " \n" + "Modified Register :" + Register_mod + " \n" + "Modified Memory Location : " + Memory + "\n" + "Activity on DRAM : " + DARM_Activity + " .\n";
                //numberOfClockCycles[coreNumber]-=1;
            }
        }
        else if (type == 1)
        {
            if (numberofClockCycles > simulation_time)
            {

                cout << "Core No :->" + to_string(coreNumber) + "\n" + "Cycle number " + to_string(simulation_time) + ": \n" + "Instruction Address: " + to_string(addr) + ", Executed Instruction ,Modified Register , Modified Memory Location && Activity on DRAM :: Pending State \n";
                // instruction_halted[coreNumber]=true;
            }
            else
            {
                cout << "Core No :->" + to_string(coreNumber) + "\n" + "Cycle number " + to_string(numberofClockCycles - COL_ACCESS_DELAY) + "-" + to_string(numberofClockCycles - 1) + ": \n " + "Instruction Address: " + to_string(addr) + ", Executed Instruction :" + inst_name + " \n" + "Modified Register : " + Register_mod + " \n" + "Modified Memory Location : " + Memory + "\n" + "Activity on DRAM : " + DARM_Activity + " .\n";
                //  numberOfClockCycles[coreNumber]-=1;
            }
        }
        else if (type == 2)
        {
            if (numberofClockCycles > simulation_time)
            {

                cout << "Core No :->" + to_string(coreNumber) + "\n" + "Cycle number " + to_string(simulation_time) + ": \n" + "Instruction Address: " + to_string(addr) + ", Executed Instruction ,Modified Register , Modified Memory Location && Activity on DRAM :: Pending State \n";
                instruction_halted[coreNumber] = true;
            }
            else
            {
                cout << "Core No :->" + to_string(coreNumber) + "\n" + "Cycle number " + to_string(numberofClockCycles - ROW_ACCESS_DELAY) + "-" + to_string(numberofClockCycles - 1) + ": \n" + "Instruction Address: " + to_string(addr) + ", Executed Instruction : " + inst_name + "\n" + "Modified Register : " + Register_mod + " \n" + "Modified Memory Location : " + Memory + "\n" + "Activity on DRAM : " + DARM_Activity + " .\n";
                numberOfClockCycles[coreNumber] -= 1;
            }
        }
    }
}

vector<int> instructionsAsVectorFromFile(string filePath, int &cnt1, int &i1, int &row, int &total_cnt, int &start, int coreNumber)
{
    fstream newfile;
    vector<int> instructions;
    unordered_map<string, int> Line_Number;
    unordered_map<int, string> map_line;
    cnt1 = 0;
    try
    {
        newfile.open(filePath, ios::in);
        if (newfile.is_open())
        {
            string tp;
            int command;
            start = i1;
            while (getline(newfile, tp))
            {
                vector<string> v; // declaring vector to store instruction command and parameters
                string s = "";    // this is used to extract valid string from stream of character
                int cnt = 0;      // this is used to handle charcter
                for (int i = 0; i < tp.size(); i++)
                {
                    if (((tp[i] - 'a') >= 0 && (tp[i] - 'a') <= 25) || (tp[i] == '$') || (tp[i] == ' ') || (tp[i] == ',') || ((tp[i] - '0') >= 0 && (tp[i] - '0') <= 9) || (tp[i] == ':') || (tp[i] == '\t') || (tp[i] == ')') || (tp[i] == '('))
                    { // condition for acception valid character
                        if (tp[i] != ' ' && tp[i] != ',' && tp[i] != '\t' && (tp[i] != ')') && (tp[i] != '('))
                        { // neglecting useless character
                            s += tp[i];
                        }
                        else
                        {
                            if (s != "")
                            {
                                v.push_back(s); // putting valid string into vector
                            }
                            s = "";
                        }
                    }
                    else
                    {
                        cout << "Invalid Syntax\n"; // Handling error for invalid syntax
                        vector<int> ret;
                        ret.push_back(-1);
                        return ret;
                    }
                }
                if (s != "")
                {
                    v.push_back(s);
                }
                int l = v.size();
                if (l == 0)
                {
                    continue;
                }
                command = instructionNumber[v[0]];
                if (command == 0)
                {
                    //  cout<<"ad1"<<"\n";       // checking whether the valid string is label or not
                    if (l == 1 && v[0][v[0].size() - 1] == ':')
                    {
                        // cout<<"fe5"<<"\n";
                        Line_Number[v[0]] = cnt1 * 4;
                    }
                    else
                    {
                        cout << "Invalid Command\n"
                             << "\n";
                        vector<int> ret;
                        ret.push_back(-1);
                        return ret;
                    }
                }
                int reg[3] = {0}; // used to store register number from 0-31 for each type of register
                for (int i = 1; i < l; i++)
                { //extracting register and converting into number from 0-31
                    if (v[i] == "$zero")
                    {
                        reg[i - 1] = 0;
                        Register_map[0] = v[i];
                    }
                    else if (v[i] == "$at")
                    {
                        reg[i - 1] = 1;
                        Register_map[1] = v[i];
                    }
                    else if (v[i] == "$gp")
                    {
                        reg[i - 1] = 28;
                        Register_map[28] = v[i];
                    }
                    else if (v[i] == "$sp")
                    {
                        reg[i - 1] = 29;
                        Register_map[29] = v[i];
                    }
                    else if (v[i] == "$fp")
                    {
                        reg[i - 1] = 30;
                        Register_map[30] = v[i];
                    }
                    else if (v[i] == "$ra")
                    {
                        reg[i - 1] = 31;
                        Register_map[31] = v[i];
                    }
                    else if (v[i][0] == '$' && v[i][1] == 'v')
                    {
                        if (stoi(v[i].substr(2)) >= 0 && stoi(v[i].substr(2)) <= 1)
                        {
                            reg[i - 1] = stoi(v[i].substr(2)) + 2;
                            Register_map[reg[i - 1]] = v[i];
                        }
                        else
                        {
                            cout << v[i] << " is invalid register."
                                 << "\n";
                            vector<int> ret;
                            ret.push_back(-1);
                            return ret;
                        }
                    }
                    else if (v[i][0] == '$' && v[i][1] == 'a')
                    {
                        if (stoi(v[i].substr(2)) >= 0 && stoi(v[i].substr(2)) <= 3)
                        {
                            reg[i - 1] = stoi(v[i].substr(2)) + 4;
                            Register_map[reg[i - 1]] = v[i];
                        }
                        else
                        {
                            cout << v[i] << " is invalid register."
                                 << "\n";
                            vector<int> ret;
                            ret.push_back(-1);
                            return ret;
                        }
                    }
                    else if (v[i][0] == '$' && v[i][1] == 't')
                    {
                        if (stoi(v[i].substr(2)) <= 7 && stoi(v[i].substr(2)) >= 0)
                        {
                            reg[i - 1] = stoi(v[i].substr(2)) + 8;
                            Register_map[reg[i - 1]] = v[i];
                        }
                        else if (stoi(v[i].substr(2)) <= 9 && stoi(v[i].substr(2)) >= 8)
                        {
                            reg[i - 1] = stoi(v[i].substr(2)) + 16;
                            Register_map[reg[i - 1]] = v[i];
                        }
                        else
                        {
                            cout << v[i] << " is invalid register."
                                 << "\n";
                            vector<int> ret;
                            ret.push_back(-1);
                            return ret;
                        }
                    }
                    else if (v[i][0] == '$' && v[i][1] == 's')
                    {
                        if (stoi(v[i].substr(2)) >= 0 && stoi(v[i].substr(2)) <= 7)
                        {
                            reg[i - 1] = stoi(v[i].substr(2)) + 16;
                            Register_map[reg[i - 1]] = v[i];
                        }
                        else
                        {
                            cout << v[i] << " is invalid register."
                                 << "\n";
                            vector<int> ret;
                            ret.push_back(-1);
                            return ret;
                        }
                    }
                    else if (v[i][0] == '$' && v[i][1] == 'k')
                    {
                        if (stoi(v[i].substr(2)) >= 0 && stoi(v[i].substr(2)) <= 1)
                        {
                            reg[i - 1] = stoi(v[i].substr(2)) + 26;
                            Register_map[reg[i - 1]] = v[i];
                        }
                        else
                        {
                            cout << v[i] << " is invalid register."
                                 << "\n";
                            vector<int> ret;
                            ret.push_back(-1);
                            return ret;
                        }
                    }
                    else if (v[i][0] == '$')
                    { // assuming that label cannot start with $ symbol
                        cout << "Invalid Register used:"
                             << "\n";
                        vector<int> ret;
                        ret.push_back(-1);
                        return ret;
                    }
                }
                // Storing values in DRAM corresponding to different operators.
                if (l == 4)
                { // this store all 9 operation except "unconditional jump"
                    cnt1++;
                    total_cnt++;
                    instructions.push_back(command);
                    if (command < 4 || command == 6)
                    {
                        instructions.push_back(reg[0]);
                        instructions.push_back(reg[1]);
                        instructions.push_back(reg[2]);
                    }
                    else if (command == 8 || command == 9)
                    { //handling "lw" and "sw"
                        instructions.push_back(reg[0]);
                        instructions.push_back(stoi(v[2]));
                        instructions.push_back(reg[2]);
                    }
                    else
                    {
                        if (v[0] == "addi")
                        {
                            instructions.push_back(reg[0]);
                            instructions.push_back(reg[1]);
                            instructions.push_back(stoi(v[3]));
                        }
                        else
                        {
                            instructions.push_back(reg[0]);
                            instructions.push_back(reg[1]);
                            instructions.push_back(-2);
                            map_line[cnt1] = v[3] + ":";
                        }
                    }
                    i1 = i1 + 4;
                    //  cout<<"hi ";
                }
                else if (l == 2)
                {   // j operator
                    // cout<<"hello ";
                    cnt1++;
                    total_cnt++;
                    instructions.push_back(command);
                    instructions.push_back(-2);
                    instructions.push_back(0);
                    instructions.push_back(0);
                    map_line[cnt1] = v[1] + ":";
                    i1 = i1 + 4;
                    //cout<<"hi ";
                }
            }
            auto it = map_line.begin(); // for label type operator mapping label string with "line number in instruction memory where one suppose to jump"
            while (it != map_line.end())
            {
                //   cout<<"loop"<<"\n";
                if (instructions.at(((it->first) * 4 - 1)) == -2)
                {
                    instructions.at(((it->first) * 4 - 1)) = Line_Number[it->second];
                }
                else
                {
                    instructions.at(((it->first) * 4 - 3)) = Line_Number[it->second];
                }
                it++;
            }
            // cout<<"gege";
            //cout<<"\n";
            v_line_no.push_back({start, 4 * cnt1});
            return instructions;
        }
        else
        {
            cout << "Cannot open file\n";
            vector<int> ret;
            ret.push_back(-1);
            return ret;
        }
    }
    catch (const std::exception &e)
    {
        cerr << "Invalid syntax in file " << filePath << "fsdf"
             << "\n"; //Through error
        vector<int> ret;
        ret.push_back(-1);
        return ret;
    }
}
bool check_memory_address(int memory_address, int coreNumber, int x)
{ // vert that memory _address used in lw and sw are valid or not
    if (memory_address % 4 != 0)
    {
        cout << "Error:\n";
        cout << "Memory of "
                "DATA INSTRUCTION"
                " cannot be used for store operation and  Memory_Address must be multiple of 4 as per DRAM_MEMORY Architecture"
             << "\n";
        return true;
    }
    else if (memory_address % 4 != 0 && memory_address >= x)
    {
        cout << "Error:\n";
        cout << "Memory  "
                "OUT OF BOUND"
                " cannot be used for store operation and  Memory_Address must be multiple of 4 as per DRAM_MEMORY Architecture"
             << "\n";
        return true;
    }
    else if (memory_address % 4 != 0)
    {
        cout << "Error:\n";
        cout << "Memory_Address must be multiple of 4 as per DRAM_MEMORY Architecture"
             << "\n";
        return true;
    }
    // else if(memory_address <1024*dramMemoryRange[coreNumber].first){
    //     cout<<"Error:\n";
    //     cout<<"Memory of ""DATA INSTRUCTION"" cannot be used for store operation "<<"\n";
    //     return true;

    // }
    else if (memory_address >= x)
    {
        cout << "Error:\n";
        cout << "Memory  "
                "OUT OF BOUND"
                " cannot be used for store operation "
             << "\n";
        return true;
    }
    return false;
}

void print_lw(int rowNum, vector<int> v, int coreNumber)
{
    int i;
    int st = 0, ed = 0;
    if (choice[coreNumber])
    {
        i = v[4];
    }
    else
    {
        i = idx_num;
    }
    int memory_address = reg_val[coreNumber][{coreNumber, i}];
    //  cout<<"print_lw "<<coreNumber<<" "<<i <<" \n";
    // cout<<reg_val[coreNumber][{coreNumber,i}]<<"\n";
    if (row == -1)
    {
        row = rowNum;
        if (!choice[coreNumber])
        {
            int ex = (COL_ACCESS_DELAY + ROW_ACCESS_DELAY) - excess[coreNumber];
            numberOfClockCycles[coreNumber] -= ex;
            excess[coreNumber] += 2;
        }
        update_cycle1(numberOfClockCycles[coreNumber] + 1, numberOfClockCycles[coreNumber] + 2, coreNumber);
        if ((numberOfClockCycles[coreNumber] + 1) <= simulation_time)
        {
            cout << "Core No : ->" + to_string(coreNumber) << "\nCycle Number :" + to_string(numberOfClockCycles[coreNumber]) + "-" + to_string(numberOfClockCycles[coreNumber] + 1) + ":: "
                 << "Memory Request Manager : Deciding next instruction to be executed "
                 << "\n";
            numberOfClockCycles[coreNumber] += 1;
        }
        else
        {
            cout << "Core No : ->" + to_string(coreNumber) << "\nCycle Number :" + to_string(simulation_time) + ":: "
                 << "Memory Request Manager : Pending State"
                 << "\n";
            numberOfClockCycles[coreNumber] += 1;
        }
        st = numberOfClockCycles[coreNumber];
        //cout<<st<<"dfsa"<<"\n";
        if (choice[coreNumber])
        {
            //ed=ed+ROW_ACCESS_DELAY+COL_ACCESS_DELAY+excess[coreNumber]-2;
            ed = st + ROW_ACCESS_DELAY + COL_ACCESS_DELAY - 1;
        }
        else
        {
            // cout<<"sfsdfd"<<"\n";
            //ed=st+ROW_ACCESS_DELAY+COL_ACCESS_DELAY-1;

            //st=numberOfClockCycles[coreNumber]+excess[coreNumber];
            ed = st;
            if (excess[coreNumber] == 0)
                ed = st + 1;
            ed = ed + excess[coreNumber] - 1;
            st = ed - (ROW_ACCESS_DELAY + COL_ACCESS_DELAY);
        }
        //cout<<ed<<"efs"<<"\n";
        update_cycle(st + 1, ed, coreNumber);
        load_data(Row_Buffer, DRAM, row);
        if (choice[coreNumber])
        {
            numberOfClockCycles[coreNumber] += ROW_ACCESS_DELAY;
            printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 2, 8, numberOfClockCycles[coreNumber], i, "Nothing", "Nothing", "Nothing", "Loading row " + to_string(row) + " into row-buffer");
        }
        col = reg_val[coreNumber][{coreNumber, i}] % 1024;
        registers2D.at(coreNumber)[Instruction_command_mem[coreNumber][(i + 1)]] = Row_Buffer[col];
        number_of_row_buffer_update += 1;
        if (choice[coreNumber])
        {
            numberOfClockCycles[coreNumber] += COL_ACCESS_DELAY;
            printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 1, 8, numberOfClockCycles[coreNumber] + 1, i, "Nothing", Register_map[Instruction_command_mem[coreNumber][(i + 1)]] + " = " + to_string(Row_Buffer[col]), "Nothing", "DRAM column access and write value in register");
        }
        else
        {
            if (excess[coreNumber] == 0)
            {
                numberOfClockCycles[coreNumber] += 1;
            }
            numberOfClockCycles[coreNumber] += excess[coreNumber];
            printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 1, 8, numberOfClockCycles[coreNumber] + 1, i, "Nothing", Register_map[Instruction_command_mem[coreNumber][(i + 1)]] + " = " + to_string(Row_Buffer[col]), "Nothing", "Loading row " + to_string(row) + " into row-buffer " + " :-> " + " DRAM column access and write value in register");
            choice[coreNumber] = true;
        }
    }
    else if (row >= 0 && row < 1024)
    {
        // cout<<i<<"\n";
        //cout<<"gds"<<reg_val[coreNumber][{coreNumber,i}]<<"\n";
        //     update_cycle1(numberOfClockCycles[coreNumber]+1,numberOfClockCycles[coreNumber]+2,coreNumber);
        //    if((numberOfClockCycles[coreNumber]+1)<=simulation_time){
        //        cout<<"Core No : ->" +to_string(coreNumber)<<"\nCycle Number :"+to_string(numberOfClockCycles[coreNumber])+"-"+to_string(numberOfClockCycles[coreNumber]+1)+":: "<<"Memory Request Manager : Deciding next instruction to be executed "<<"\n";
        //        numberOfClockCycles[coreNumber]+=1;
        //     }else{
        //          cout<<"Core No : ->" +to_string(coreNumber)<<"\nCycle Number :"+to_string(simulation_time)+":: "<<"Memory Request Manager : Pending State"<<"\n";
        //          numberOfClockCycles[coreNumber]+=1;
        //     }
        if (row == reg_val[coreNumber][{coreNumber, i}] / 1024)
        {
            //    if((numberOfClockCycles[coreNumber]+1)<=simulation_time){
            //     //cout<<row<<"\n";
            //    cout<<"Core No : ->" +to_string(coreNumber)<<"\nCycle Number :"+to_string(numberOfClockCycles[coreNumber]+1)+":: "<<"Memory Request Manager : Easy Access"<<"\n";
            //    numberOfClockCycles[coreNumber]+=1;
            //  }else{
            //      cout<<"Core No : ->" +to_string(coreNumber)<<"\nCycle Number :"+to_string(numberOfClockCycles[coreNumber]+1)+":: "<<"Memory Request Manager : Pending State"<<"\n";
            //      numberOfClockCycles[coreNumber]+=1;
            // }
            if (!choice[coreNumber])
            {
                int ex = (COL_ACCESS_DELAY)-excess[coreNumber];
                numberOfClockCycles[coreNumber] -= ex;
                excess[coreNumber] += 2;
            }
            update_cycle1(numberOfClockCycles[coreNumber] + 1, numberOfClockCycles[coreNumber] + 2, coreNumber);
            if ((numberOfClockCycles[coreNumber] + 1) <= simulation_time)
            {
                cout << "Core No : ->" + to_string(coreNumber) << "\nCycle Number :" + to_string(numberOfClockCycles[coreNumber]) + "-" + to_string(numberOfClockCycles[coreNumber] + 1) + ":: "
                     << "Memory Request Manager : Deciding next instruction to be executed "
                     << "\n";
                numberOfClockCycles[coreNumber] += 1;
            }
            else
            {
                cout << "Core No : ->" + to_string(coreNumber) << "\nCycle Number :" + to_string(simulation_time) + ":: "
                     << "Memory Request Manager : Pending State"
                     << "\n";
                numberOfClockCycles[coreNumber] += 1;
            }
            st = numberOfClockCycles[coreNumber];
            if (choice[coreNumber])
            {
                ed = st + COL_ACCESS_DELAY - 1;
                //  if(excess[coreNumber]==0) ed=st+1;
                //  ed=ed+COL_ACCESS_DELAY+excess[coreNumber]-2;
            }
            else
            {
                ed = st;
                if (excess[coreNumber] == 0)
                    ed = st + 1;
                ed = ed + excess[coreNumber] - 1;
                st = ed - (COL_ACCESS_DELAY);
            }
            update_cycle(st + 1, ed, coreNumber);
            col = reg_val[coreNumber][{coreNumber, i}] % 1024;
            registers2D.at(coreNumber)[Instruction_command_mem[coreNumber][(i + 1)]] = Row_Buffer[col];

            if (choice[coreNumber])
            {
                numberOfClockCycles[coreNumber] += COL_ACCESS_DELAY;
                printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 1, 8, numberOfClockCycles[coreNumber] + 1, i, "Nothing", Register_map[Instruction_command_mem[coreNumber][(i + 1)]] + " = " + to_string(Row_Buffer[col]), "Nothing", "DRAM column access and write value in register");
            }
            else
            {
                if (excess[coreNumber] == 0)
                {
                    numberOfClockCycles[coreNumber] += 1;
                }
                numberOfClockCycles[coreNumber] += excess[coreNumber];
                printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 1, 8, numberOfClockCycles[coreNumber] + 1, i, "Nothing", Register_map[Instruction_command_mem[coreNumber][(i + 1)]] + " = " + to_string(Row_Buffer[col]), "Nothing", "DRAM column access and write value in register");
                choice[coreNumber] = true;
            }
        }
        else
        {
            load_data_back(Row_Buffer, DRAM, row);

            // if((numberOfClockCycles[coreNumber]+2)<=simulation_time){
            //  cout<<"Core No : ->" +to_string(coreNumber)<<"\nCycle Number :"+to_string(numberOfClockCycles[coreNumber]+1)+"-"+to_string(numberOfClockCycles[coreNumber]+2)+":: "<<"Memory Request Manager : Complex Access"<<"\n";
            //  numberOfClockCycles[coreNumber]+=2;
            // }else{
            //  cout<<"Core No : ->" +to_string(coreNumber)<<"\nCycle Number :"+to_string(numberOfClockCycles[coreNumber]+1)+"-"+to_string(numberOfClockCycles[coreNumber]+2)+":: "<<"Memory Request Manager : Pending State"<<"\n";
            //  numberOfClockCycles[coreNumber]+=1;
            // }
            if (!choice[coreNumber])
            {
                int ex = (COL_ACCESS_DELAY + 2 * ROW_ACCESS_DELAY) - excess[coreNumber];
                numberOfClockCycles[coreNumber] -= ex;
                excess[coreNumber] += 2;
            }
            update_cycle1(numberOfClockCycles[coreNumber] + 1, numberOfClockCycles[coreNumber] + 2, coreNumber);
            if ((numberOfClockCycles[coreNumber] + 1) <= simulation_time)
            {
                cout << "Core No : ->" + to_string(coreNumber) << "\nCycle Number :" + to_string(numberOfClockCycles[coreNumber]) + "-" + to_string(numberOfClockCycles[coreNumber] + 1) + ":: "
                     << "Memory Request Manager : Deciding next instruction to be executed "
                     << "\n";
                numberOfClockCycles[coreNumber] += 1;
            }
            else
            {
                cout << "Core No : ->" + to_string(coreNumber) << "\nCycle Number :" + to_string(simulation_time) + ":: "
                     << "Memory Request Manager : Pending State"
                     << "\n";
                numberOfClockCycles[coreNumber] += 1;
            }
            st = numberOfClockCycles[coreNumber];
            if (choice[coreNumber])
            {
                ed = st + 2 * ROW_ACCESS_DELAY + COL_ACCESS_DELAY - 1;
            }
            else
            {
                ed = st;
                if (excess[coreNumber] == 0)
                    ed = st + 1;
                ed = ed + excess[coreNumber] - 1;
                st = ed - (2 * ROW_ACCESS_DELAY + COL_ACCESS_DELAY);
            }

            update_cycle(st + 1, ed, coreNumber);
            if (choice[coreNumber])
            {
                numberOfClockCycles[coreNumber] += ROW_ACCESS_DELAY;
                printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 2, 8, numberOfClockCycles[coreNumber] + 1, i, "Nothing", "Nothing", "Nothing", "Write-back row: " + to_string(row));
            }

            row = reg_val[coreNumber][{coreNumber, i}] / 1024;
            load_data(Row_Buffer, DRAM, row);

            if (choice[coreNumber])
            {

                numberOfClockCycles[coreNumber] += ROW_ACCESS_DELAY;
                printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 2, 8, numberOfClockCycles[coreNumber] + 1, i, "Nothing", "Nothing", "Nothing", "Loading row " + to_string(row) + " into row-buffer ");
            }

            col = reg_val[coreNumber][{coreNumber, i}] % 1024;
            registers2D.at(coreNumber)[Instruction_command_mem[coreNumber][(i + 1)]] = Row_Buffer[col];

            number_of_row_buffer_update += 1;
            if (choice[coreNumber])
            {

                numberOfClockCycles[coreNumber] += COL_ACCESS_DELAY;
                printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 1, 8, numberOfClockCycles[coreNumber] + 1, i, "Nothing", Register_map[Instruction_command_mem[coreNumber][(i + 1)]] + " = " + to_string(Row_Buffer[col]), "Nothing ", "DRAM column access and write value in register");
            }
            else
            {

                if (excess[coreNumber] == 0)
                {
                    numberOfClockCycles[coreNumber] += 1;
                }
                numberOfClockCycles[coreNumber] += excess[coreNumber];
                printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 1, 8, numberOfClockCycles[coreNumber] + 1, i, "Nothing", Register_map[Instruction_command_mem[coreNumber][(i + 1)]] + " = " + to_string(Row_Buffer[col]), "Nothing ", "Write-back row: " + to_string(row) + " :-> " + " Loading row " + to_string(row) + " into row-buffer " + " :-> " + "DRAM column access and write value in register");
                choice[coreNumber] = true;
            }
        }
    }
}
void print_sw(int rowNum, vector<int> v, int coreNumber)
{
    // cout<<rowNum<<"::"<<"\n";
    int i;
    int st = 0, ed = 0;
    if (choice[coreNumber])
    {
        i = v[4];
    }
    else
    {
        i = idx_num;
    }
    // cout<<i<<"\n";
    int memory_address = reg_val[coreNumber][{coreNumber, i}];
    // cout<<"print_sw "<<coreNumber<<" "<<i <<" \n";
    // cout<<reg_val[coreNumber][{coreNumber,i}]<<"\n";
    if (row == -1)
    { // When first time "sw" is called (means when row_buffer is empty)
        row = rowNum;
        if (!choice[coreNumber])
        {
            int ex = (ROW_ACCESS_DELAY + COL_ACCESS_DELAY) - excess[coreNumber];
            //cout<<ex<<"\n";
            // cout<<numberOfClockCycles[coreNumber]<<"\n";
            numberOfClockCycles[coreNumber] -= ex;
            excess[coreNumber] += 2;
        }
        update_cycle1(numberOfClockCycles[coreNumber] + 1, numberOfClockCycles[coreNumber] + 2, coreNumber);
        if ((numberOfClockCycles[coreNumber] + 1) <= simulation_time)
        {
            cout << "Core No : ->" + to_string(coreNumber) << "\nCycle Number :" + to_string(numberOfClockCycles[coreNumber]) + "-" + to_string(numberOfClockCycles[coreNumber] + 1) + ":: "
                 << "Memory Request Manager : Deciding next instruction to be executed "
                 << "\n";
            numberOfClockCycles[coreNumber] += 1;
        }
        else
        {
            cout << "Core No : ->" + to_string(coreNumber) << "\nCycle Number :" + to_string(simulation_time) + ":: "
                 << "Memory Request Manager : Pending State"
                 << "\n";
            numberOfClockCycles[coreNumber] += 1;
        }
        //     st=numberOfClockCycles[coreNumber]+1;
        //    if(choice[coreNumber]){
        //             if(excess[coreNumber]==0) ed=st+1;
        //             ed=ed+ROW_ACCESS_DELAY+COL_ACCESS_DELAY+excess[coreNumber]-2;
        //    }else{
        //         ed=st+ROW_ACCESS_DELAY+COL_ACCESS_DELAY-1;
        //     }
        st = numberOfClockCycles[coreNumber];
        //cout<<st<<"dfsa"<<"\n";
        if (choice[coreNumber])
        {
            //ed=ed+ROW_ACCESS_DELAY+COL_ACCESS_DELAY+excess[coreNumber]-2;
            ed = st + ROW_ACCESS_DELAY + COL_ACCESS_DELAY - 1;
        }
        else
        {
            // cout<<"sfsdfd"<<"\n";
            //ed=st+ROW_ACCESS_DELAY+COL_ACCESS_DELAY-1;
            //st=numberOfClockCycles[coreNumber]+excess[coreNumber];
            ed = st;
            if (excess[coreNumber] == 0)
                ed = st + 1;
            ed = ed + excess[coreNumber] - 1;
            st = ed - (ROW_ACCESS_DELAY + COL_ACCESS_DELAY);
        }
        update_cycle(st + 1, ed, coreNumber);
        //row =reg_val[coreNumber][{coreNumber,i}]/1024;
        //  cout<<row<<"->"<<"\n";
        load_data(Row_Buffer, DRAM, row);
        if (choice[coreNumber])
        {
            numberOfClockCycles[coreNumber] += ROW_ACCESS_DELAY;
            printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 2, 9, numberOfClockCycles[coreNumber], i, "Nothing", "Nothing", "Nothing", "Activate row: " + to_string(row));
        }
        col = reg_val[coreNumber][{coreNumber, i}] % 1024;
        Row_Buffer[col] = registers2D.at(coreNumber)[Instruction_command_mem[coreNumber][i + 1]];
        number_of_row_buffer_update += 2;
        if (choice[coreNumber])
        {
            numberOfClockCycles[coreNumber] += COL_ACCESS_DELAY;
            printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 1, 9, numberOfClockCycles[coreNumber] + 1, i, "Nothing", "Nothing", "Address " + to_string(memory_address) + " = " + to_string(Row_Buffer[col]), "DRAM column access and update");
        }
        else
        {
            if (excess[coreNumber] == 0)
            {
                numberOfClockCycles[coreNumber] += 1;
            }
            numberOfClockCycles[coreNumber] += excess[coreNumber];
            printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 1, 9, numberOfClockCycles[coreNumber] + 1, i, "Nothing", "Nothing", "Address " + to_string(memory_address) + " = " + to_string(Row_Buffer[col]), "Activate row: " + to_string(row) + " :-> " + "DRAM column access and update");
            choice[coreNumber] = true;
        }
    }
    else if (row >= 0 && row < 1024)
    {
        if (row == (reg_val[coreNumber][{coreNumber, i}]) / 1024)
        { // it same row come and only column_offset requirr to modify data
            col = reg_val[coreNumber][{coreNumber, i}] % 1024;
            // if((numberOfClockCycles[coreNumber]+1)<=simulation_time){
            //    cout<<"Core No : ->" +to_string(coreNumber)<<"\nCycle Number :"+to_string(numberOfClockCycles[coreNumber]+1)+":: "<<"Memory Request Manager : Easy Access"<<"\n";
            //    numberOfClockCycles[coreNumber]+=1;
            // }else{
            //      cout<<"Core No : ->" +to_string(coreNumber)<<"\nCycle Number :"+to_string(numberOfClockCycles[coreNumber]+1)+":: "<<"Memory Request Manager : Pending State"<<"\n";
            //      numberOfClockCycles[coreNumber]+=1;
            // }
            // st=numberOfClockCycles[coreNumber]+1;
            // if(choice[coreNumber]){
            //      if(excess[coreNumber]==0) ed=st+1;
            //      ed=ed+COL_ACCESS_DELAY+excess[coreNumber]-2;
            // }else{
            //     ed=st+COL_ACCESS_DELAY-1;
            // }
            // update_cycle(st,ed,coreNumber);
            //  cout<<row<<":"<<"\n";
            if (!choice[coreNumber])
            {
                int ex = (COL_ACCESS_DELAY)-excess[coreNumber];
                numberOfClockCycles[coreNumber] -= ex;
                excess[coreNumber] += 2;
            }
            update_cycle1(numberOfClockCycles[coreNumber] + 1, numberOfClockCycles[coreNumber] + 2, coreNumber);
            if ((numberOfClockCycles[coreNumber] + 1) <= simulation_time)
            {
                cout << "Core No : ->" + to_string(coreNumber) << "\nCycle Number :" + to_string(numberOfClockCycles[coreNumber]) + "-" + to_string(numberOfClockCycles[coreNumber] + 1) + ":: "
                     << "Memory Request Manager : Deciding next instruction to be executed "
                     << "\n";
                numberOfClockCycles[coreNumber] += 1;
            }
            else
            {
                cout << "Core No : ->" + to_string(coreNumber) << "\nCycle Number :" + to_string(simulation_time) + ":: "
                     << "Memory Request Manager : Pending State"
                     << "\n";
                numberOfClockCycles[coreNumber] += 1;
            }
            st = numberOfClockCycles[coreNumber];
            if (choice[coreNumber])
            {
                ed = st + COL_ACCESS_DELAY - 1;
                //  if(excess[coreNumber]==0) ed=st+1;
                //  ed=ed+COL_ACCESS_DELAY+excess[coreNumber]-2;
            }
            else
            {
                ed = st;
                if (excess[coreNumber] == 0)
                    ed = st + 1;
                ed = ed + excess[coreNumber] - 1;
                st = ed - (COL_ACCESS_DELAY);
            }
            update_cycle(st + 1, ed, coreNumber);
            Row_Buffer[col] = registers2D.at(coreNumber)[Instruction_command_mem[coreNumber][i + 1]];
            number_of_row_buffer_update += 1;
            if (choice[coreNumber])
            {
                numberOfClockCycles[coreNumber] += COL_ACCESS_DELAY;
                printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 1, 9, numberOfClockCycles[coreNumber] + 1, i, "Nothing", "Nothing", "Address " + to_string(memory_address) + " = " + to_string(Row_Buffer[col]), "DRAM column access and update");
            }
            else
            {
                if (excess[coreNumber] == 0)
                {
                    numberOfClockCycles[coreNumber] += 1;
                }
                numberOfClockCycles[coreNumber] += excess[coreNumber];
                printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 1, 9, numberOfClockCycles[coreNumber] + 1, i, "Nothing", "Nothing", "Address " + to_string(memory_address) + " = " + to_string(Row_Buffer[col]), "DRAM column access and update");
                choice[coreNumber] = true;
            }
        }
        else
        { // When row's come different then writing back and copying take place along with column offset
            load_data_back(Row_Buffer, DRAM, row);
            //    if((numberOfClockCycles[coreNumber]+2)<=simulation_time){
            //        cout<<"Core No : ->" +to_string(coreNumber)<<"\nCycle Number :"+to_string(numberOfClockCycles[coreNumber]+1)+"-"+to_string(numberOfClockCycles[coreNumber]+2)+":: "<<"Memory Request Manager : Complex Access"<<"\n";
            //        numberOfClockCycles[coreNumber]+=2;
            //     }else{
            //          cout<<"Core No : ->" +to_string(coreNumber)<<"\nCycle Number :"+to_string(numberOfClockCycles[coreNumber]+1)+"-"+to_string(numberOfClockCycles[coreNumber]+2)+":: "<<"Memory Request Manager : Pending State"<<"\n";
            //          numberOfClockCycles[coreNumber]+=2;
            //     }
            // st=numberOfClockCycles[coreNumber]+1;
            // if(choice[coreNumber]){
            //   if(excess[coreNumber]==0) ed=st+1;
            //       ed=ed+2*ROW_ACCESS_DELAY+excess[coreNumber]-2;
            //   }else{
            //        ed=st+2*ROW_ACCESS_DELAY+COL_ACCESS_DELAY-1;
            // }
            // update_cycle(st,ed,coreNumber);
            if (!choice[coreNumber])
            {
                int ex = (COL_ACCESS_DELAY + 2 * ROW_ACCESS_DELAY) - excess[coreNumber];
                numberOfClockCycles[coreNumber] -= ex;
                excess[coreNumber] += 2;
            }
            update_cycle1(numberOfClockCycles[coreNumber] + 1, numberOfClockCycles[coreNumber] + 2, coreNumber);
            if ((numberOfClockCycles[coreNumber] + 1) <= simulation_time)
            {
                cout << "Core No : ->" + to_string(coreNumber) << "\nCycle Number :" + to_string(numberOfClockCycles[coreNumber]) + "-" + to_string(numberOfClockCycles[coreNumber] + 1) + ":: "
                     << "Memory Request Manager : Deciding next instruction to be executed "
                     << "\n";
                numberOfClockCycles[coreNumber] += 1;
            }
            else
            {
                cout << "Core No : ->" + to_string(coreNumber) << "\nCycle Number :" + to_string(simulation_time) + ":: "
                     << "Memory Request Manager : Pending State"
                     << "\n";
                numberOfClockCycles[coreNumber] += 1;
            }
            st = numberOfClockCycles[coreNumber];
            if (choice[coreNumber])
            {
                ed = st + 2 * ROW_ACCESS_DELAY + COL_ACCESS_DELAY - 1;
            }
            else
            {
                ed = st;
                if (excess[coreNumber] == 0)
                    ed = st + 1;
                ed = ed + excess[coreNumber] - 1;
                st = ed - (2 * ROW_ACCESS_DELAY + COL_ACCESS_DELAY);
            }

            update_cycle(st + 1, ed, coreNumber);
            if (choice[coreNumber])
            {
                numberOfClockCycles[coreNumber] += ROW_ACCESS_DELAY;
                printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 2, 9, numberOfClockCycles[coreNumber] + 1, i, "Nothing", "Nothing", "Nothing", "Write-back row: " + to_string(row));
            }
            //row=(Instruction_command_mem[coreNumber][(i+2)] + registers2D.at(coreNumber)[Instruction_command_mem[coreNumber][(i+3)]])/1024;
            row = reg_val[coreNumber][{coreNumber, i}] / 1024;
            //cout<<row<<":::"<<"\n";
            load_data(Row_Buffer, DRAM, row);
            if (choice[coreNumber])
            {
                numberOfClockCycles[coreNumber] += ROW_ACCESS_DELAY;
                printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 2, 9, numberOfClockCycles[coreNumber] + 1, i, "Nothing", "Nothing", "Nothing", "Activate row: " + to_string(row));
            }
            col = reg_val[coreNumber][{coreNumber, i}] % 1024;
            Row_Buffer[col] = registers2D.at(coreNumber)[Instruction_command_mem[coreNumber][(i + 1)]];
            number_of_row_buffer_update += 2;
            if (choice[coreNumber])
            {
                numberOfClockCycles[coreNumber] += COL_ACCESS_DELAY;
                printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 1, 9, numberOfClockCycles[coreNumber] + 1, i, "Nothing", "Nothing", "Address " + to_string(memory_address) + " = " + to_string(Row_Buffer[col]), " DRAM column access and update");
            }
            else
            {
                if (excess[coreNumber] == 0)
                {
                    numberOfClockCycles[coreNumber] += 1;
                }
                numberOfClockCycles[coreNumber] += excess[coreNumber];
                printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 1, 9, numberOfClockCycles[coreNumber] + 1, i, "Nothing", "Nothing", "Address " + to_string(memory_address) + " = " + to_string(Row_Buffer[col]), "Write-back row: " + to_string(row) + " :->" + "Activate row: " + to_string(row) + " :-> DRAM column access and update");
                choice[coreNumber] = true;
            }
        }
    }
    DRAM[(reg_val[coreNumber][{coreNumber, i}]) / 1024][(reg_val[coreNumber][{coreNumber, i}]) % 1024] = registers2D.at(coreNumber)[Instruction_command_mem[coreNumber][(i + 1)]];
}

void parallel_instruction(int val, int coreNumber)
{

    int shuru = dramMemoryRange.at(coreNumber).first;
    int khatam = dramMemoryRange.at(coreNumber).second;
    // cout<<shuru<<"ferfsdgclera"<<khatam<<"\n";
    //  cout<<counter[coreNumber]<<"\n";
    if (counter[coreNumber] >= delay_num)
    {
        int tmp1 = -1;
        //   cout<<"fdsa4"<<"\n";
        for (int i = shuru; i <= khatam; i++)
        {
            if (!queueArray[i].empty())
            {
                choice[coreNumber] = false;
                tmp1 = i;
                break;
            }
        }
        if (tmp1 != -1)
        {
            vector<int> v_d = queueArray[tmp1].front();
            deque<vector<int>> q1;
            q1.push_back(v_d);
            queueArray[tmp1].pop_front();
            auto it_copy = q1.begin();
            counter[coreNumber] = counter[coreNumber] - (delay_num);
            idx_num = v_d[4];
            if (v_d[0] == 8)
            {
                print_lw(tmp1, (*it_copy), coreNumber);
            }
            else
            {
                print_sw(tmp1, (*it_copy), coreNumber);
            }
        }
    }
    else if (val == 1 && counter[coreNumber] > 0)
    {
        int tmp1 = -1;
        //   cout<<"1"<<"\n";
        for (int i = shuru; i <= khatam; i++)
        {
            if (!queueArray[i].empty())
            {
                choice[coreNumber] = false;
                tmp1 = i;
                // cout<<"@"<<"\n";
                break;
            }
        }
        if (tmp1 != -1)
        {
            vector<int> v_d = queueArray[tmp1].front();
            deque<vector<int>> q1;
            q1.push_back(v_d);
            queueArray[tmp1].pop_front();
            auto it_copy = q1.begin();
            //   cout<<"fdsd"<<"\n";
            excess[coreNumber] = (delay_num)-counter[coreNumber];
            counter[coreNumber] = 0;
            idx_num = v_d[4];
            if (v_d[0] == 8)
            {
                print_lw(tmp1, (*it_copy), coreNumber);
            }
            else
            {
                // cout<<(*it_copy)[4]<<"\n";

                print_sw(tmp1, (*it_copy), coreNumber);
            }
        }
    }
}

void Non_blocking_check(int val, int coreNumber)
{
    //cout<<"yes"<<" "<<coreNumber<<"\n";
    if (row != -1 && check_counter(coreNumber))
    {
        if (!queueArray[row].empty() && check1(row, coreNumber))
        {
            if (counter[coreNumber] >= COL_ACCESS_DELAY)
            {
                while (counter[coreNumber] >= COL_ACCESS_DELAY && !queueArray[row].empty())
                {
                    choice[coreNumber] = false;
                    vector<int> v_d = queueArray[row].front();
                    deque<vector<int>> q1;
                    q1.push_back(v_d);
                    counter[coreNumber] = counter[coreNumber] - COL_ACCESS_DELAY;
                    excess[coreNumber] = -counter[coreNumber];
                    queueArray[row].pop_front();
                    auto it_copy = q1.begin();
                    idx_num = v_d[4];
                    if (v_d[0] == 8)
                    {
                        print_lw(row, (*it_copy), coreNumber);
                    }
                    else
                    {
                        print_sw(row, (*it_copy), coreNumber);
                    }
                }
            }
            if (val == 1 && counter[coreNumber] > 0)
            {
                choice[coreNumber] = false;
                vector<int> v_d = queueArray[row].front();
                deque<vector<int>> q1;
                q1.push_back(v_d);
                queueArray[row].pop_front();
                excess[coreNumber] = COL_ACCESS_DELAY - counter[coreNumber];
                counter[coreNumber] = 0;
                auto it_copy = q1.begin();
                idx_num = v_d[4];
                if (v_d[0] == 8)
                {
                    print_lw(row, (*it_copy), coreNumber);
                }
                else
                {
                    print_sw(row, (*it_copy), coreNumber);
                }
            }
        }
        else if (counter[coreNumber] <= 2 * ROW_ACCESS_DELAY + COL_ACCESS_DELAY && val == 1)
        {
            //  cout<<"hi123"<<"\n";
            delay_num = 2 * ROW_ACCESS_DELAY + COL_ACCESS_DELAY;
            parallel_instruction(1, coreNumber);
        }
    }
    else if (counter[coreNumber] > 0 && row == -1)
    {
        // cout<<"hi1234"<<"\n";
        if (check_counter(coreNumber) && val != 1)
        {
            //   cout<<"hi1235"<<"\n";
            delay_num = ROW_ACCESS_DELAY + COL_ACCESS_DELAY;
            parallel_instruction(0, coreNumber);
        }
        else if (check_counter(coreNumber) && val == 1)
        {
            //   cout<<"hi12356"<<"\n";
            delay_num = ROW_ACCESS_DELAY + COL_ACCESS_DELAY;
            parallel_instruction(1, coreNumber);
        }
        else
        {
            //  cout<<"hi123567"<<"\n";
            counter[coreNumber] = 0;
        }
    }
}
void executeQueue(deque<vector<int>> &q, int rowNum, int coreNumber)
{
    auto it = q.begin();
    while (it != q.end())
    {
        if ((*it)[0] == 8)
        {
            print_lw(rowNum, (*it), coreNumber);
        }
        else
        {
            print_sw(rowNum, (*it), coreNumber);
        }
        it++;
    }
}
void execute(set<int> &s_row, int coreNumber)
{
    if (check_counter(coreNumber))
    {
        Non_blocking_check(1, coreNumber);
    }
    else
    {
        counter[coreNumber] = 0;
    }
    auto it1 = s_row.begin();
    int j = 0;
    deque<vector<int>> q;
    while (it1 != s_row.end() && row != -1)
    {
        j = (*it1);
        if (j == row)
        {
            q = queueArray[j];
            executeQueue(q, j, coreNumber);
            queueArray[j].clear();
            s_row.erase(it1);
            break;
        }
        it1++;
    }
    auto it = s_row.begin();
    while (it != s_row.end())
    {
        int i = (*it);
        q = queueArray[i];
        executeQueue(q, i, coreNumber);
        queueArray[i].clear();
        it++;
    }
}

void check_redundant(int add_ress, int coreNumber)
{
    int row_ = (add_ress) / 1024;
    auto it = queueArray[row_].begin();

    while (it != queueArray[row_].end())
    {
        if (reg_val[coreNumber][{coreNumber, (*it)[4]}] == add_ress)
        {
            numberOfClockCycles[coreNumber] += 1;
            cout << "Core No :->" << coreNumber << " "
                 << "Cycle_Number: " << numberOfClockCycles[coreNumber] << " : DRAM call skipped"
                 << "\n";

            queueArray[row_].erase(it);
        }
        if (it != queueArray[row_].end())
        {
            it++;
        }
    }
}

void memory_limit_check(int coreNumber)
{

    int total = 0;
    int max_size_limit = 32 * num_of_CPU_cores;

    for (int i = 0; i < 1024; i++)
    {
        total += queueArray[i].size();
    }
    if (total > max_size_limit)
    {
        Non_blocking_check(0, coreNumber);
    }
}

void isSafe(vector<int> &v_2, int coreNumber)
{
    set<int> s_row;
    int shuru = dramMemoryRange.at(coreNumber).first;
    int khatam = dramMemoryRange.at(coreNumber).second;
    //cout<<shuru<<"->"<<khatam<<"\n";
    if (v_2[0] == 1 || v_2[0] == 2 || v_2[0] == 3 || v_2[0] == 6)
    {
        for (int i = shuru; i <= khatam; i++)
        {
            if (!queueArray[i].empty())
            {
                // cout<<i<<"\n";
                auto it = queueArray[i].begin();
                while (it != queueArray[i].end())
                {
                    if ((*it)[0] == 8)
                    {
                        if ((((*it)[1] == v_2[1] && (*it)[1] != v_2[2] && (*it)[1] != v_2[3]) && (*it)[1] != 0))
                        {
                            numberOfClockCycles[coreNumber] += 1;
                            cout << "Core No :->" << coreNumber << " "
                                 << "Cycle_Number: " << numberOfClockCycles[coreNumber] << " : DRAM call skipped"
                                 << "\n";

                            queueArray[i].erase(it);
                            if (it != queueArray[i].end())
                            {
                                it++;
                            }
                        }
                        else if ((((*it)[1] == v_2[1] || (*it)[1] == v_2[2] || (*it)[1] == v_2[3]) && (*it)[1] != 0))
                        {
                            //it++;
                            s_row.insert(i);
                            break;
                        }
                        else
                        {
                            it++;
                        }
                    }
                    else
                    {
                        if ((*it)[1] == v_2[1])
                        {
                            s_row.insert(i);
                            break;
                        }
                        else
                        {
                            it++;
                        }
                    }
                }
            }
        }
    }
    else if (v_2[0] == 4 || v_2[0] == 5)
    {
        for (int i = shuru; i <= khatam; i++)
        {
            if (!queueArray[i].empty())
            {
                auto it = queueArray[i].begin();
                while (it != queueArray[i].end())
                {
                    if ((*it)[0] == 8)
                    {
                        if (((*it)[1] == v_2[1] || (*it)[1] == v_2[2]) && ((*it)[1] != 0))
                        {

                            s_row.insert(i);
                            break;
                        }
                        else
                        {
                            it++;
                        }
                    }
                    else
                    {
                        it++;
                    }
                }
            }
        }
    }
    else if (v_2[0] == 10)
    {
        for (int i = shuru; i <= khatam; i++)
        {
            if (!queueArray[i].empty())
            {
                auto it = queueArray[i].begin();
                while (it != queueArray[i].end())
                {
                    if ((*it)[0] == 8)
                    {
                        if (((*it)[1] == v_2[1] && (*it)[1] != v_2[2]) && ((*it)[1] != 0))
                        {
                            numberOfClockCycles[coreNumber] += 1;
                            cout << "Core No :->" << coreNumber << " "
                                 << "Cycle_Number: " << numberOfClockCycles[coreNumber] << " : DRAM call skipped"
                                 << "\n";

                            queueArray[i].erase(it);
                            if (it != queueArray[i].end())
                            {
                                it++;
                            }
                        }
                        else if (((*it)[1] == v_2[1] || (*it)[1] == v_2[2]) && ((*it)[1] != 0))
                        {
                            s_row.insert(i);
                            //it++;
                            break;
                        }
                        else
                        {
                            it++;
                        }
                    }
                    else
                    {
                        if ((*it)[1] == v_2[1])
                        {

                            s_row.insert(i);

                            break;
                        }
                        else
                        {
                            it++;
                        }
                    }
                }
            }
        }
    }
    else if (v_2[0] == 8)
    {
        for (int i = shuru; i <= khatam; i++)
        {
            if (!queueArray[i].empty())
            {
                // cout<<i<<"\n";
                auto it = queueArray[i].begin();
                while (it != queueArray[i].end())
                {
                    if ((*it)[0] == 8)
                    {
                        if (((*it)[1] == v_2[1] && (*it)[1] != 0) && ((*it)[1] != v_2[3] && (*it)[1] != 0))
                        {
                            numberOfClockCycles[coreNumber] += 1;
                            cout << "Core No :->" << coreNumber << " "
                                 << "Cycle_Number: " << numberOfClockCycles[coreNumber] << " : DRAM call skipped"
                                 << "\n";

                            queueArray[i].erase(it);
                            if (it != queueArray[i].end())
                            {
                                it++;
                            }
                        }
                        else if (((*it)[1] == v_2[1] && (*it)[1] != 0) || ((*it)[1] == v_2[3] && (*it)[1] != 0))
                        {
                            s_row.insert(i);
                            break;
                        }
                        else
                        {
                            it++;
                        }
                    }
                    else
                    {
                        if ((*it)[1] == v_2[1])
                        {
                            s_row.insert(i);
                            break;
                        }
                        else
                        {
                            it++;
                        }
                    }
                }
            }
        }
    }
    else if (v_2[0] == 9)
    {
        int q = 1;
        for (int i = shuru; i <= khatam; i++)
        {
            if (!queueArray[i].empty())
            {
                auto it = queueArray[i].begin();
                while (it != queueArray[i].end())
                {
                    if ((*it)[0] == 8)
                    {
                        if (((*it)[1] == v_2[1] && (*it)[1] != 0) || ((*it)[1] == v_2[3] && (*it)[1] != 0))
                        {
                            q = 0;
                            s_row.insert(i);
                            break;
                        }
                        else
                        {
                            it++;
                        }
                    }
                    else
                    {
                        it++;
                    }
                }
            }
        }
        if (q)
        {
            int addres;
            vector<int> instructions = Instruction_command_mem.at(coreNumber);
            if (coreNumber != 0)
            {
                addres = (dramMemoryRange[coreNumber - 1].second + 1) * 1024 + (instructions.at(v_2[4] + 2) + registers2D[coreNumber].at(instructions.at(v_2[4] + 3)));
            }
            else
            {
                addres = (instructions.at(v_2[4] + 2) + registers2D[coreNumber].at(instructions.at(v_2[4] + 3)));
            }
            check_redundant(addres, coreNumber);
        }
    }
    auto it = s_row.begin();
    // while(it!=s_row.end()){
    //     cout<<*it<<"";
    //     it++;
    // }
    // cout<<"\n";
    if (s_row.size() != 0)
    {
        // cout<<"hello"<<"\n";
        execute(s_row, coreNumber);
    }
}

int executeInstruction(int coreNumber)
{
    int i = line[coreNumber];
    int j = 0;
    vector<int> instructions = Instruction_command_mem.at(coreNumber);

    while (i < (instructions.size()) && j != -1)
    {
        if (i == -1 || (instructions.at(i) == 0 && instructions.at(i + 1) == 0 && instructions.at(i + 2) == 0 && instructions.at(i + 3) == 0))
        { // Exiting condition for the program
            instruction_halted[coreNumber] = true;
            break;
        }
        if (instruction_halted[coreNumber])
        {
            return -1;
            //break;
        }
        int memory_address;
        int c = instructions.at(i);
        if (c == 8 || c == 9)
        {
            memory_address = instructions.at(i + 2) + registers2D[coreNumber].at(instructions.at(i + 3));
        }
        vector<int> v_1;
        switch (c)
        {
        case 1: //add
            if (check_counter(coreNumber))
            {
                Non_blocking_check(0, coreNumber);
            }
            else
            {
                counter[coreNumber] = 0;
            }
            v_1.push_back(1);
            v_1.push_back(instructions.at(i + 1));
            v_1.push_back(instructions.at(i + 2));
            v_1.push_back(instructions.at(i + 3));
            v_1.push_back(i);
            isSafe(v_1, coreNumber);
            numberOfClockCycles[coreNumber]++;
            freqOfCommand2D[coreNumber][0]++;
            counter[coreNumber]++;
            registers2D[coreNumber].at(instructions.at(i + 1)) = registers2D[coreNumber].at(instructions.at(i + 2)) + registers2D[coreNumber].at(instructions.at(i + 3));
            printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 0, 1, numberOfClockCycles[coreNumber], i,
                                      "add", Register_map[instructions.at(i + 1)] + " = " + to_string(instructions.at(i + 1)), "Nothing ", "Nothing");
            i = i + 4;
            line[coreNumber] = i;
            break;
        case 2: //sub
            if (check_counter(coreNumber))
            {
                Non_blocking_check(0, coreNumber);
            }
            else
            {
                counter[coreNumber] = 0;
            }
            v_1.push_back(2);
            v_1.push_back(instructions.at(i + 1));
            v_1.push_back(instructions.at(i + 2));
            v_1.push_back(instructions.at(i + 3));
            v_1.push_back(i);
            isSafe(v_1, coreNumber);
            numberOfClockCycles[coreNumber]++;
            freqOfCommand2D[coreNumber].at(1)++;
            counter[coreNumber]++;
            registers2D[coreNumber].at(instructions.at(i + 1)) = registers2D[coreNumber].at(instructions.at(i + 2)) - registers2D[coreNumber].at(instructions.at(i + 3));
            printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 0, 2, numberOfClockCycles[coreNumber], i,
                                      "sub", Register_map[instructions.at(i + 1)] + " = " + to_string(registers2D[coreNumber].at(instructions.at(i + 1))), "Nothing ", "Nothing");
            i = i + 4;
            line[coreNumber] = i;
            break;
        case 3: //mul
            if (check_counter(coreNumber))
            {
                Non_blocking_check(0, coreNumber);
            }
            else
            {
                counter[coreNumber] = 0;
            }
            v_1.push_back(3);
            v_1.push_back(instructions.at(i + 1));
            v_1.push_back(instructions.at(i + 2));
            v_1.push_back(instructions.at(i + 3));
            v_1.push_back(i);
            isSafe(v_1, coreNumber);
            numberOfClockCycles[coreNumber]++;
            freqOfCommand2D[coreNumber].at(2)++;
            counter[coreNumber]++;
            registers2D[coreNumber].at(instructions.at(i + 1)) = registers2D[coreNumber].at(instructions.at(i + 2)) * registers2D[coreNumber].at(instructions.at(i + 3));
            printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 0, 3, numberOfClockCycles[coreNumber], i,
                                      "mul", Register_map[instructions.at(i + 1)] + " = " + to_string(registers2D[coreNumber].at(instructions.at(i + 1))), "Nothing ", "Nothing");
            i = i + 4;
            line[coreNumber] = i;
            break;
        case 4: //beq
            if (check_counter(coreNumber))
            {
                Non_blocking_check(0, coreNumber);
            }
            else
            {
                counter[coreNumber] = 0;
            }
            v_1.push_back(4);
            v_1.push_back(instructions.at(i + 1));
            v_1.push_back(instructions.at(i + 2));
            v_1.push_back(instructions.at(i + 3));
            v_1.push_back(i);
            isSafe(v_1, coreNumber);
            numberOfClockCycles[coreNumber]++;
            freqOfCommand2D[coreNumber].at(3)++;
            counter[coreNumber]++;
            if (registers2D[coreNumber].at(instructions.at(i + 1)) == registers2D[coreNumber].at(instructions.at(i + 2)))
            {
                printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 0, 4, numberOfClockCycles[coreNumber], i,
                                          "beq", "Nothing ", "Nothing ", "Nothing");
                i = instructions.at(i + 3);
                line[coreNumber] = i;
                if (i % 4 != 0 || i < 0 || i >= instructions.size() * 4)
                {
                    cout << "Invalid Memory Excess\n";
                    remove_instruction(coreNumber);
                    return 1;
                }
                break;
            }
            else
            {
                printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 0, 4, numberOfClockCycles[coreNumber], i,
                                          "beq", "Nothing ", "Nothing ", "Nothing");
                i = i + 4;
                line[coreNumber] = i;
                break;
            }
        case 5: //bne
            if (check_counter(coreNumber))
            {
                Non_blocking_check(0, coreNumber);
            }
            else
            {
                counter[coreNumber] = 0;
            }
            v_1.push_back(5);
            v_1.push_back(instructions.at(i + 1));
            v_1.push_back(instructions.at(i + 2));
            v_1.push_back(instructions.at(i + 3));
            v_1.push_back(i);
            isSafe(v_1, coreNumber);
            numberOfClockCycles[coreNumber]++;
            freqOfCommand2D[coreNumber][4]++;
            counter[coreNumber]++;

            if (registers2D[coreNumber].at(instructions.at(i + 1)) != registers2D[coreNumber].at(instructions.at(i + 2)))
            {
                printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 0, 5, numberOfClockCycles[coreNumber], i,
                                          "bne", "Nothing ", "Nothing ", "Nothing");
                i = instructions.at(i + 3);
                line[coreNumber] = i;
                if (i % 4 != 0 || i < 0 || i >= instructions.size() * 4)
                {
                    cout << "Invalid Memory Excess\n";
                    remove_instruction(coreNumber);
                    return 1;
                }
                // printRegisters(numberOfClockCycles);
                break;
            }
            else
            {
                printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 0, 5, numberOfClockCycles[coreNumber], i,
                                          "bne", "Nothing ", "Nothing ", "Nothing");
                i = i + 4;
                line[coreNumber] = i;
                if (i % 4 != 0 || i < 0 || i >= instructions.size() * 4)
                {
                    cout << "Invalid Memory Excess\n";
                    remove_instruction(coreNumber);
                    return 1;
                }
                // printRegisters(numberOfClockCycles);
                break;
            }
        case 6: //slt
            if (check_counter(coreNumber))
            {
                Non_blocking_check(0, coreNumber);
            }
            else
            {
                counter[coreNumber] = 0;
            }
            v_1.push_back(6);
            v_1.push_back(instructions.at(i + 1));
            v_1.push_back(instructions.at(i + 2));
            v_1.push_back(instructions.at(i + 3));
            v_1.push_back(i);
            isSafe(v_1, coreNumber);
            numberOfClockCycles[coreNumber]++;
            freqOfCommand2D[coreNumber].at(5)++;
            counter[coreNumber]++;
            if (registers2D[coreNumber].at(instructions.at(i + 2)) < registers2D[coreNumber].at(instructions.at(i + 3)))
            {
                registers2D[coreNumber].at(instructions.at(i + 1)) = 1;
            }
            else
            {
                registers2D[coreNumber].at(instructions.at(i + 1)) = 0;
            }
            printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 0, 6, numberOfClockCycles[coreNumber], i, "slt", Register_map[instructions.at(i + 1)] + " = " + to_string(registers2D[coreNumber].at(instructions.at(i + 1))), "Nothing ", "Nothing");
            i = i + 4;
            line[coreNumber] = i;
            break;
        case 7: // jump
            if (check_counter(coreNumber))
            {
                Non_blocking_check(0, coreNumber);
            }
            else
            {
                counter[coreNumber] = 0;
            }
            numberOfClockCycles[coreNumber]++;
            freqOfCommand2D[coreNumber].at(6)++;
            counter[coreNumber]++;
            printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 0, 7, numberOfClockCycles[coreNumber], i, "j", "Nothing ", "Nothing ", "Nothing");
            i = instructions.at(i + 1);
            line[coreNumber] = i;
            if (i % 4 != 0 || i < 0 || i >= x)
            {
                remove_instruction(coreNumber);
                cout << "Invalid Memory Excess\n";
                return 1;
            }
            break;
        case 8: // lw
            if (check_counter(coreNumber))
            {
                Non_blocking_check(0, coreNumber);
            }
            else
            {
                counter[coreNumber] = 0;
            }
            numberOfClockCycles[coreNumber]++;
            freqOfCommand2D[coreNumber].at(7)++;
            printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 0, 8, numberOfClockCycles[coreNumber], i, "lw", "Nothing", "Nothing", "DRAM request issued");
            if (check_memory_address(memory_address, coreNumber, x))
            {
                remove_instruction(coreNumber);
                return 1; //terminate the program
            }
            else
            {
                v_1.push_back(8);
                v_1.push_back(instructions.at(i + 1));
                v_1.push_back(instructions.at(i + 2));
                v_1.push_back(instructions.at(i + 3));
                v_1.push_back(i);
                isSafe(v_1, coreNumber);
                if (check_counter(coreNumber))
                    counter[coreNumber]++;
                int temp1;
                memory_limit_check(coreNumber);
                if (coreNumber != 0)
                {
                    temp1 = (dramMemoryRange[coreNumber - 1].second + 1) * 1024 + (instructions.at(i + 2) + registers2D[coreNumber].at(instructions.at(i + 3)));
                }
                else
                {
                    temp1 = (instructions.at(i + 2) + registers2D[coreNumber].at(instructions.at(i + 3)));
                }
                // cout<<"lw "<<coreNumber<<" "<<i<<"\n";
                reg_val.at(coreNumber)[{coreNumber, i}] = temp1;
                // cout<< reg_val.at(coreNumber)[{coreNumber,i}]<<"\n";
                //cout<<reg_val[coreNumber][{coreNumber,i}]<<" ";

                int row1;
                if (coreNumber != 0)
                {
                    row1 = ((dramMemoryRange[coreNumber - 1].second + 1) * 1024 + instructions.at(i + 2) + registers2D[coreNumber].at(instructions.at(i + 3))) / 1024;
                    // cout<<row1<<"fsdfdsfs"<<"\n";
                }
                else
                {
                    row1 = (instructions.at(i + 2) + registers2D[coreNumber].at(instructions.at(i + 3))) / 1024;
                }
                queueArray[row1].push_back(v_1);
                // if(queueArray[row1].size()>maxQueueSizePermitted){
                //     // Do one of the following:
                //     // Fully empty this row
                //     // Just execute top most function
                // }
            }
            i = i + 4;
            line[coreNumber] = i;
            break;
        case 9: // sw
            if (check_counter(coreNumber))
            {
                Non_blocking_check(0, coreNumber);
            }
            else
            {
                counter[coreNumber] = 0;
            }
            numberOfClockCycles[coreNumber]++;
            //  cout<<numberOfClockCycles[coreNumber]<<" "<<coreNumber<<"\n";
            freqOfCommand2D[coreNumber].at(8)++;
            printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 0, 9, numberOfClockCycles[coreNumber], i, "sw", "Nothing", "Nothing", "DRAM request issued");
            if (check_memory_address(memory_address, coreNumber, x))
            {
                remove_instruction(coreNumber);
                return 1; //terminate the program
            }
            else
            {
                v_1.push_back(9);
                v_1.push_back(instructions.at(i + 1));
                v_1.push_back(instructions.at(i + 2));
                v_1.push_back(instructions.at(i + 3));
                v_1.push_back(i);
                isSafe(v_1, coreNumber);
                if (check_counter(coreNumber))
                    counter[coreNumber]++;
                int temp1;
                memory_limit_check(coreNumber);
                if (coreNumber != 0)
                {
                    temp1 = (dramMemoryRange[coreNumber - 1].second + 1) * 1024 + (instructions.at(i + 2) + registers2D[coreNumber].at(instructions.at(i + 3)));
                }
                else
                {
                    temp1 = (instructions.at(i + 2) + registers2D[coreNumber].at(instructions.at(i + 3)));
                }
                // cout<<"sw "<<coreNumber<<" "<<i<<"\n";
                reg_val.at(coreNumber)[{coreNumber, i}] = temp1;
                //cout<< reg_val.at(coreNumber)[{coreNumber,i}]<<"\n";
                int row1;
                if (coreNumber != 0)
                {
                    row1 = ((dramMemoryRange[coreNumber - 1].second + 1) * 1024 + instructions.at(i + 2) + registers2D[coreNumber].at(instructions.at(i + 3))) / 1024;
                }
                else
                {
                    row1 = (instructions.at(i + 2) + registers2D[coreNumber].at(instructions.at(i + 3))) / 1024;
                }
                queueArray[row1].push_back(v_1);
                if (queueArray[row1].size() > maxQueueSizePermitted)
                {
                    // Do one of the following:
                    // Fully empty this row
                    // Just execute top most function
                }
            }
            i = i + 4;
            line[coreNumber] = i;
            break;
        case 10: //addi
            if (check_counter(coreNumber))
            {
                Non_blocking_check(0, coreNumber);
            }
            else
            {
                counter[coreNumber] = 0;
            }
            v_1.push_back(10);
            v_1.push_back(instructions.at(i + 1));
            v_1.push_back(instructions.at(i + 2));
            v_1.push_back(instructions.at(i + 3));
            v_1.push_back(i);
            isSafe(v_1, coreNumber);
            numberOfClockCycles[coreNumber]++;
            freqOfCommand2D[coreNumber].at(9)++;
            counter[coreNumber]++;
            registers2D[coreNumber].at(instructions.at(i + 1)) = registers2D[coreNumber].at(instructions.at(i + 2)) + instructions.at(i + 3);
            printChange_in_Each_Cycle(coreNumber, ROW_ACCESS_DELAY, COL_ACCESS_DELAY, 0, 10, numberOfClockCycles[coreNumber], i, "addi", Register_map[instructions.at(i + 1)] + " = " + to_string(registers2D[coreNumber].at(instructions.at(i + 1))), "Nothing ", "Nothing");
            i = i + 4;
            line[coreNumber] = i;
            break;
        default:
            i = -1;
        }
        v_1.clear();
        if (line[coreNumber] >= instructions.size())
        {

            return -1;
        }
        else
        {
            j = -1;
        }
    }
    return 0;
}

int main(int argc, char **argv)
{
    int i1 = -4;
    int total_cnt = 0;
    int start = 0;
    num_of_CPU_cores = stoi(argv[1]);
    simulation_time = stoi(argv[2]);
    instructionNumber["add"] = 1; // mapping of instuction with number so that it can easily handle as number while using array
    instructionNumber["sub"] = 2;
    instructionNumber["mul"] = 3;
    instructionNumber["beq"] = 4;
    instructionNumber["bne"] = 5;
    instructionNumber["slt"] = 6;
    instructionNumber["j"] = 7;
    instructionNumber["lw"] = 8;
    instructionNumber["sw"] = 9;
    instructionNumber["addi"] = 10;
    int sizeOfEachCore = 1024 / num_of_CPU_cores;
    for (int i = 0; i < num_of_CPU_cores; i++)
    {
        numberOfCyclesForEachCore.push_back(0);
        numberOfClockCycles.push_back(0);
        excess.push_back(0);
        choice.push_back(true);
        instruction_halted.push_back(false);
        line.push_back(0);
        counter.push_back(0);
        map<pair<int, int>, int> temp;
        reg_val.push_back(temp);
        int startMem = (1024 / num_of_CPU_cores) * i;
        int endMem = (1024 / num_of_CPU_cores) * (i + 1) - 1;
        dramMemoryRange.push_back({startMem, endMem});
    }
    pair<int, int> lastPair;
    lastPair.first = (1024 / num_of_CPU_cores) * (num_of_CPU_cores - 1);
    lastPair.second = 1023;
    dramMemoryRange.at(num_of_CPU_cores - 1) = lastPair;

    for (int i = 0; i < num_of_CPU_cores; i++)
    {
        cnt1 += 1;
        i1 += 4;
        row = -1;
        vector<int> temp;
        for (int j = 0; j < 10; j++)
        { // Initialise frequency of command
            temp.push_back(0);
        }
        freqOfCommand2D.push_back(temp);
        vector<int> temp1;
        for (int j = 0; j < 32; j++)
        { // Initialise registers vector
            temp1.push_back(0);
        }
        registers2D.push_back(temp1);
        string filePath = argv[i + 3];
        Instruction_command_mem.push_back(instructionsAsVectorFromFile(filePath, cnt1, i1, row, total_cnt, start, i));
    }

    ROW_ACCESS_DELAY = stoi(argv[num_of_CPU_cores + 3]);
    COL_ACCESS_DELAY = stoi(argv[num_of_CPU_cores + 4]);
    // for(int i=0;i<num_of_CPU_cores;i++){
    //     vector<int> temp = Instruction_command_mem.at(i);
    //     // for(int j=0;j<temp.size();j++){
    //     //     cout<<temp.at(j)<<" ";
    //     // }
    //     // cout<<"\n";
    // }
    vector<int> status(num_of_CPU_cores, 0);
    vector<int> numberOfClockCycles1;
    vector<int> flag1;
    for (int i = 0; i < num_of_CPU_cores; i++)
    {
        flag1.push_back(false);
        numberOfClockCycles1.push_back(0);
    }
    while (general_check())
    {
        for (int i = 0; i < num_of_CPU_cores; i++)
        {
            // cout<<"Helo1"<<"  "<<numberOfClockCycles[i]<<"\n";
            if (status[i] != -1)
            {
                //cout<<"Helo2"<<"\n";
                int x = numberOfClockCycles[i];
                // cout<<i<<"   "<<instruction_halted[i]<<"    "<<numberOfClockCycles[i]<<"\n";
                status[i] = executeInstruction(i);
                if ((numberOfClockCycles[i] - x) == 0)
                {
                    status[i] = -1;
                }
                cout << "\n";
            }
            else if (!instruction_halted[i])
            {
                // cout<<"Hel3"<<"\n";
                if (check_counter(i))
                {
                    if (counter[i] != 0)
                    {
                        Non_blocking_check(1, i);
                    }
                    int ck = 0;
                    for (int j = dramMemoryRange.at(i).first; j <= dramMemoryRange.at(i).second; j++)
                    {
                        // cout<<queueArray[j].size()<<"\n";
                        if (!queueArray[j].empty())
                        {
                            //  cout<<"He4lo"<<"\n";
                            ck = -1;
                            deque<vector<int>> q = queueArray[j];
                            executeQueue(q, j, i);
                            queueArray[j].clear();
                            break;
                        }
                    }
                    cout << "\n";
                    if (ck == 0)
                    {
                        instruction_halted[i] = true;
                    }
                }
                else
                {
                    // cout<<"He5lo"<<"\n";
                    if (numberOfClockCycles[i] <= simulation_time)
                    {
                        // cout<<"H6elo"<<"\n";

                        if (flag1[i] == false)
                        {
                            numberOfClockCycles1[i] = numberOfClockCycles[i];
                            flag1[i] = true;
                        }
                        numberOfClockCycles[i]++;
                        cout << "Core Number " << i << " "
                             << "Cycle Number : " << numberOfClockCycles[i] << "::-> "
                             << ": Nothing\n";
                    }
                    else
                    {
                        // cout<<"Hel7o"<<"\n";
                        instruction_halted[i] = true;
                    }

                    cout << "\n";
                }
            }
            else if (numberOfClockCycles[i] <= simulation_time)
            {
                // cout<<"He524lo"<<"\n";

                if (flag1[i] == false)
                {
                    numberOfClockCycles1[i] = numberOfClockCycles[i];
                    flag1[i] = true;
                }
                numberOfClockCycles[i]++;
                cout << "Core Number " << i << " "
                     << "Cycle Number : " << numberOfClockCycles[i] << "::-> "
                     << ": Nothing\n";
            }
            else if (status[i] == 1)
            {
                // cout<<"H21436elo"<<"\n";
                cout << "Core Number " << i << ": Warning\n";
                cout << "\n";
                instruction_halted[i] = true;
            }
            else
            {
                for (int j = dramMemoryRange.at(i).first; j <= dramMemoryRange.at(i).second; j++)
                {
                    if (!queueArray[j].empty())
                    {
                        queueArray[j].clear();
                    }
                    instruction_halted[i] = true;
                }
            }
        }
        //  cout<<"\n";
        // break;
        //  cout<<"hi"<<"\n";
    }
    for (int i = 0; i < num_of_CPU_cores; i++)
    {
        if (numberOfClockCycles1[i] == 0)
        {
            numberOfClockCycles1[i] = numberOfClockCycles[i];
        }
    }
    int totalCommands = 0;
    int time = -1;
    for (int i = 0; i < num_of_CPU_cores; i++)
    {
        time = max(time, numberOfClockCycles1[i]);
        vector<int> temp = freqOfCommand2D[i];
        for (int j = 0; j < 10; j++)
        {
            totalCommands += temp[j];
        }
    }
    time = min(simulation_time, time);
    cout << "Following are the statistics for the program:\n";
    float cpi = (float)time / (float)totalCommands;
    cout << "CPI: " << cpi << "\n";
    float throughput = (float)totalCommands / (float)time;
    cout << "Throughput:" << throughput << " or " << throughput * 100 << "%"
         << "\n";
    cout << "Total number of buffer updates: " << number_of_row_buffer_update << "\n";
    cout << "Time spent in each core: \n";
    for (int i = 0; i < num_of_CPU_cores; i++)
    {
        cout << "Core " << i << ": " << min(simulation_time, numberOfClockCycles1[i]) << "\n";
    }
    cout << "\n";
    return 0;
}
